<!-- header styles -->

<link id="u-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
<style>.u-header {
  background-image: none;
}
.u-header .u-sheet-1 {
  min-height: 225px;
}
.u-header .u-image-1 {
  margin: 23px auto 0 18px;
}
.u-header .u-logo-image-1 {
  max-width: 324px;
  max-height: 324px;
}
.u-header .u-menu-1 {
  margin: -84px 17px 60px auto;
}
.u-header .u-nav-1 {
  font-size: 1.5rem;
  letter-spacing: 0px;
  text-transform: uppercase;
  font-weight: 700;
}
.u-block-a7ca-19 {
  box-shadow: 2px 2px 8px 0 rgba(128,128,128,1);
}
.u-header .u-nav-2 {
  font-size: 1.25rem;
}
.u-block-a7ca-20 {
  box-shadow: 2px 2px 8px 0 rgba(128,128,128,1);
}
@media (max-width: 1199px) {
  .u-header .u-image-1 {
    width: auto;
    margin-top: 34px;
    margin-left: 0;
  }
  .u-header .u-logo-image-1 {
    max-width: 225px;
    max-height: 225px;
  }
  .u-header .u-menu-1 {
    width: auto;
    margin-top: -70px;
    margin-right: 0;
  }
}
@media (max-width: 991px) {
  .u-header .u-image-1 {
    margin-top: 28px;
    height: 32px;
  }
  .u-header .u-logo-image-1 {
    max-width: 256px;
    max-height: 256px;
  }
}
@media (max-width: 767px) {
  .u-header .u-image-1 {
    margin-top: 30px;
    margin-left: 20px;
  }
  .u-header .u-logo-image-1 {
    max-width: 259px;
    max-height: 259px;
  }
  .u-header .u-menu-1 {
    margin-top: -84px;
    margin-right: 20px;
  }
}
@media (max-width: 575px) {
  .u-header .u-sheet-1 {
    min-height: 163px;
  }
  .u-header .u-image-1 {
    margin-top: 35px;
    margin-left: 0;
  }
  .u-header .u-logo-image-1 {
    max-width: 206px;
    max-height: 206px;
  }
  .u-header .u-menu-1 {
    margin-top: -68px;
    margin-right: 0;
  }
}</style>
